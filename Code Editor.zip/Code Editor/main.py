import os
import tkinter as tk
from tkinter import filedialog, messagebox
from tkinterweb import HtmlFrame  # Используем tkinterweb для отображения HTML

class CodeEditorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Code Editor")
        self.current_file = None
        self.files = []  # Список для хранения открытых файлов
        self.selected_folder = ""  # Путь к выбранной папке

        # Установка тёмной темы
        self.root.configure(bg="#2E2E2E")

        # Панель файлов
        self.file_frame = tk.Frame(self.root, bg="#2E2E2E")
        self.file_frame.pack(side=tk.LEFT, fill=tk.Y)

        self.open_folder_button = tk.Button(self.file_frame, text="Open Folder", command=self.open_folder, bg="#444", fg="#ffffff")
        self.open_folder_button.pack(pady=10)

        self.save_button = tk.Button(self.file_frame, text="Save", command=self.save_project, bg="#444", fg="#ffffff")
        self.save_button.pack(pady=10)

        self.update_button = tk.Button(self.file_frame, text="Update", command=self.update_file_list, bg="#444", fg="#ffffff")
        self.update_button.pack(pady=10)

        self.file_listbox = tk.Listbox(self.file_frame, bg="#3E3E3E", fg="#ffffff", selectbackground="#555555")
        self.file_listbox.pack(fill=tk.BOTH, expand=True)

        # Редактор кода
        self.code_editor = tk.Text(self.root, wrap=tk.WORD, width=40, height=20, bg="#3E3E3E", fg="#ffffff", insertbackground='white')
        self.code_editor.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Панель предпросмотра
        self.preview_frame = tk.Frame(self.root, bg="#FFFFFF")  # Установим белый фон
        self.preview_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        self.html_viewer = HtmlFrame(self.preview_frame)  # Используем HtmlFrame для отображения HTML
        self.html_viewer.pack(fill=tk.BOTH, expand=True)

        # Добавляем обработчик для автоматического сохранения и обновления предпросмотра
        self.code_editor.bind('<KeyRelease>', self.update_preview)

    def open_folder(self):
        folder_path = filedialog.askdirectory()
        if folder_path:
            self.selected_folder = folder_path  # Сохраняем путь к выбранной папке
            self.load_files(folder_path)

    def load_files(self, directory):
        self.file_listbox.delete(0, tk.END)
        self.files = []  # Очищаем список файлов
        for file in os.listdir(directory):
            if file.endswith('.html') or file.endswith('.css') or file.endswith('.js'):
                self.file_listbox.insert(tk.END, file)
                self.files.append(os.path.join(directory, file))  # Добавляем полный путь к файлам

        self.file_listbox.bind('<<ListboxSelect>>', self.open_file)

    def open_file(self, event):
        selection = self.file_listbox.curselection()
        if selection:
            file_name = self.file_listbox.get(selection[0])
            self.current_file = os.path.join(self.selected_folder, file_name)  # Используем сохраненный путь
            try:
                with open(self.current_file, 'r', encoding='utf-8') as file:  # Указываем кодировку UTF-8
                    content = file.read()
                    self.code_editor.delete(1.0, tk.END)
                    self.code_editor.insert(tk.END, content)
                    self.update_preview()  # Обновляем предпросмотр
            except UnicodeDecodeError:
                messagebox.showerror("Ошибка", "Не удалось открыть файл. Проверьте кодировку.")

    def auto_save(self, event=None):
        """Автоматически сохраняет изменения в текущем файле."""
        if self.current_file:
            try:
                # Сохраняем содержимое редактора в файл
                content = self.code_editor.get(1.0, tk.END)
                with open(self.current_file, 'w', encoding='utf-8') as file:
                    file.write(content)
            except Exception as e:
                messagebox.showerror("Ошибка", f"Не удалось сохранить файл: {e}")

    def save_project(self):
        """Сохраняет все файлы в один итоговый файл в папке 'saves'."""
        if not self.files:
            messagebox.showerror("Ошибка", "Нет открытых файлов для сохранения.")
            return

        combined_content = self.combine_files()

        # Создаем папку 'saves', если она не существует
        saves_folder = os.path.join(self.selected_folder, 'saves')
        os.makedirs(saves_folder, exist_ok=True)

        output_file = os.path.join(saves_folder, "project.html")
        index = 1
        while os.path.exists(output_file):
            output_file = os.path.join(saves_folder, f"project{index}.html")
            index += 1

        # Сохраняем итоговый файл
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(combined_content)

        messagebox.showinfo("Успех", f"Файл сохранен как {output_file}")

    def combine_files(self):
        """Объединяет HTML, CSS и JS файлы в один HTML-код."""
        combined_content = "<!DOCTYPE html>\n<html lang='ru'>\n<head>\n<meta charset='UTF-8'>\n<title>Итоговый проект</title>\n"
        
        # Добавляем CSS с помощью тега <style>
        for file in self.files:
            if file.endswith('.css'):
                with open(file, 'r', encoding='utf-8') as f:
                    css_content = f.read()
                    combined_content += "<style>\n" + css_content + "\n</style>\n"

        combined_content += "</head>\n<body>\n"

        # Добавляем HTML
        for file in self.files:
            if file.endswith('.html'):
                with open(file, 'r', encoding='utf-8') as f:
                    combined_content += f.read() + "\n"

        # Добавляем JavaScript с помощью тега <script>
        for file in self.files:
            if file.endswith('.js'):
                with open(file, 'r', encoding='utf-8') as f:
                    js_content = f.read()
                    combined_content += "<script>\n" + js_content + "\n</script>\n"

        combined_content += "</body>\n</html>"
        return combined_content

    def update_file_list(self):
        """Обновляет список файлов в выбранной папке."""
        if self.selected_folder:
            self.load_files(self.selected_folder)  # Загружаем файлы из сохраненной папки
        else:
            messagebox.showerror("Ошибка", "Сначала выберите папку.")

    def update_preview(self, event=None):
        """Обновляет предпросмотр HTML в холсте."""
        html_content = self.code_editor.get(1.0, tk.END).strip()
        if html_content:
            self.html_viewer.load_html(html_content)  # Устанавливаем содержимое HTML в HtmlFrame

if __name__ == "__main__":
    root = tk.Tk()
    app = CodeEditorApp(root)
    root.geometry("1200x700")
    root.mainloop()